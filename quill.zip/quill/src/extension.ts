import * as vscode from 'vscode';
import { CommandManager } from './commands/commandManager';
import { DashboardProvider } from './providers/dashboardProvider';
import { SearchResultsEditorProvider } from './providers/searchResultsEditorProvider';
import { ChatEditorProvider } from './providers/chatEditorProvider';
import { StatusBarProvider } from './providers/statusBarProvider';
import { Logger } from './utils/logger';
import { AuthService } from './services/authService';

export function activate(context: vscode.ExtensionContext) {
    // Initialize logger
    Logger.initialize('Quill');
    Logger.info('Quill extension is starting up...');
    const commandManager = new CommandManager(context);
    commandManager.registerCommands(context);

    // Register URI handler for OAuth callback
    context.subscriptions.push(
        vscode.window.registerUriHandler({
            handleUri(uri: vscode.Uri): vscode.ProviderResult<void> {
                if (uri.path === '/auth') {
                    handleOAuthCallback(uri, context);
                }
            }
        })
    );

    // Register the search results editor provider
    const searchResultsEditorProvider = new SearchResultsEditorProvider(context);
    context.subscriptions.push(
        vscode.window.registerCustomEditorProvider(SearchResultsEditorProvider.viewType, searchResultsEditorProvider)
    );

    // Register the chat editor provider
    const chatEditorProvider = new ChatEditorProvider(context);
    context.subscriptions.push(
        vscode.window.registerCustomEditorProvider(ChatEditorProvider.viewType, chatEditorProvider)
    );

    // Register the dashboard webview provider
    const dashboardProvider = new DashboardProvider(context.extensionUri, context);
    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider(DashboardProvider.viewType, dashboardProvider)
    );

    // Store dashboard provider reference for OAuth callback
    (context as any).dashboardProvider = dashboardProvider;

    // Register refresh chat sessions command
    const refreshChatSessionsDisposable = vscode.commands.registerCommand(
        'quill.refreshChatSessions',
        () => dashboardProvider.refreshChatSessions()
    );
    context.subscriptions.push(refreshChatSessionsDisposable);

    // Register the status bar provider
    const statusBarProvider = new StatusBarProvider(context);
    context.subscriptions.push({
        dispose: () => statusBarProvider.dispose()
    });

    Logger.info('Quill extension activated successfully');
}

export function deactivate() {
    Logger.info('Quill extension is deactivating...');
    Logger.dispose();
}

async function handleOAuthCallback(uri: vscode.Uri, context: vscode.ExtensionContext) {
    try {
        Logger.info('Handling OAuth callback');
        
        // Parse query parameters
        const query = new URLSearchParams(uri.query);
        const accessToken = query.get('access_token');
        const refreshToken = query.get('refresh_token');
        const userEmail = query.get('user_email');
        const userFirstName = query.get('user_first_name');
        const userLastName = query.get('user_last_name');
        const userId = query.get('user_id');

        if (!accessToken || !userEmail) {
            throw new Error('Missing required OAuth parameters');
        }

        // Create user object
        const user = {
            id: parseInt(userId || '0'),
            email: userEmail,
            first_name: userFirstName || '',
            last_name: userLastName || '',
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };

        // Store tokens and user info
        const authService = new AuthService(context);
        await authService.storeTokens({ access_token: accessToken, refresh_token: refreshToken || '' });
        await authService.storeUser(user);

        // Refresh dashboard
        const dashboardProvider = (context as any).dashboardProvider;
        if (dashboardProvider) {
            Logger.info('Refreshing dashboard after OAuth success');
            await dashboardProvider.getAuthStatus();
        } else {
            Logger.error('Dashboard provider not found');
        }

        // Also try refreshing via command
        vscode.commands.executeCommand('quill.refreshChatSessions');

        Logger.info(`OAuth callback successful for user: ${userFirstName}`);
        vscode.window.showInformationMessage(`Welcome, ${userFirstName}!`);

    } catch (error: any) {
        Logger.error('OAuth callback failed', error);
        vscode.window.showErrorMessage(`Authentication failed: ${error.message}`);
    }
}
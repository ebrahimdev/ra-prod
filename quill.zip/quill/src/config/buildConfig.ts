// This file is generated at build time
export const BUILD_CONFIG = {
    "isProduction": false,
    "authServerUrl": "http://localhost:8001",
    "ragServerUrl": "http://localhost:8000"
};

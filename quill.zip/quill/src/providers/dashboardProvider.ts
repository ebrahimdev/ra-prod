import * as vscode from 'vscode';
import { AuthService } from '../services/authService';
import { Logger } from '../utils/logger';

export class DashboardProvider implements vscode.WebviewViewProvider {
    public static readonly viewType = 'quill.dashboard';

    private _view?: vscode.WebviewView;
    private authService: AuthService;

    constructor(
        private readonly _extensionUri: vscode.Uri,
        private readonly context: vscode.ExtensionContext
    ) {
        this.authService = new AuthService(context);
    }

    public resolveWebviewView(
        webviewView: vscode.WebviewView,
        context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken,
    ) {
        this._view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [
                this._extensionUri
            ]
        };

        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);

        // Handle messages from the webview
        webviewView.webview.onDidReceiveMessage(
            message => {
                switch (message.command) {
                    case 'signup':
                        this.handleSignup();
                        return;
                    case 'googleSignup':
                        this.handleGoogleSignup();
                        return;
                    case 'getAuthStatus':
                        this.getAuthStatus();
                        return;
                    case 'devReload':
                        // Developer utility: refresh the webview HTML
                        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);
                        return;
                }
            },
            undefined,
            this.context.subscriptions
        );

        // Load initial auth status
        this.getAuthStatus();
    }

    public async getAuthStatus() {
        try {
            Logger.info('Getting auth status...');
            const tokens = await this.authService.getStoredTokens();
            const isAuthenticated = !!tokens;
            let user = null;

            if (isAuthenticated) {
                user = await this.authService.getStoredUser();
                Logger.info(`User found: ${user?.first_name}`);
            }

            Logger.info(`Sending auth status to webview: authenticated=${isAuthenticated}, user=${user?.first_name}`);
            
            if (this._view?.webview) {
                this._view.webview.postMessage({
                    command: 'authStatus',
                    isAuthenticated: isAuthenticated,
                    user: user
                });
                Logger.info('Message sent to webview');
            } else {
                Logger.error('No webview found');
            }
        } catch (error) {
            Logger.error('Error getting auth status:', error);
            this._view?.webview.postMessage({
                command: 'authStatus',
                isAuthenticated: false,
                user: null
            });
        }
    }

    private async handleSignup() {
        vscode.commands.executeCommand('quill.register');
    }

    private async handleGoogleSignup() {
        try {
            await vscode.commands.executeCommand('quill.googleAuth');
            // Refresh auth status after successful signup
            this.getAuthStatus();
        } catch (error) {
            // Error handling is done in the command
        }
    }

    /**
     * Public method to refresh chat sessions (compatibility with extension.ts)
     */
    public refreshChatSessions() {
        // Refresh the auth status to update the dashboard
        this.getAuthStatus();
    }

    private _getHtmlForWebview(webview: vscode.Webview) {
        // Use a nonce to only allow specific scripts to be run
        const nonce = getNonce();

        return `<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}';">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Quill</title>
            <style>
                body {
                    font-family: var(--vscode-font-family);
                    font-size: var(--vscode-font-size);
                    font-weight: var(--vscode-font-weight);
                    color: var(--vscode-foreground);
                    background-color: var(--vscode-editor-background);
                    margin: 0;
                    padding: 0;
                    height: 100vh;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                }

                .container {
                    text-align: center;
                    padding: 40px 20px;
                    max-width: 300px;
                    width: 100%;
                }

                .logo {
                    font-size: 48px;
                    margin-bottom: 16px;
                    line-height: 1;
                }

                .title {
                    font-size: 24px;
                    font-weight: 600;
                    color: var(--vscode-foreground);
                    margin-bottom: 8px;
                }

                .subtitle {
                    font-size: 14px;
                    color: var(--vscode-descriptionForeground);
                    margin-bottom: 32px;
                    line-height: 1.4;
                }

                .signup-btn {
                    background-color: #007acc;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    margin: 0 20px;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 500;
                    width: calc(100% - 40px);
                    transition: background-color 0.2s ease;
                }

                .signup-btn:hover {
                    background-color: #005a9e;
                }

                .signup-btn:active {
                    transform: translateY(1px);
                }

                .authenticated-message {
                    display: none;
                    text-align: center;
                    color: var(--vscode-testing-iconPassed);
                    font-size: 16px;
                    font-weight: 500;
                }

                .authenticated-subtitle {
                    color: var(--vscode-descriptionForeground);
                    font-size: 14px;
                    margin-top: 8px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div id="unauthenticated-view">
                    <button class="signup-btn" id="signupBtn">Signup</button>
                </div>
                
                <div id="authenticated-view" class="authenticated-message">
                    <div id="welcome-message" class="authenticated-subtitle">Welcome!</div>
                    <div class="authenticated-subtitle">You're all set!</div>
                </div>
            </div>

            <script nonce="${nonce}">
                const vscode = acquireVsCodeApi();
                
                // DEV MODE: Add visual indicator that script is running
                console.log('Quill Dashboard Loaded - Version: ${Date.now()}');
                
                // Handle messages from extension
                window.addEventListener('message', event => {
                    const message = event.data;
                    console.log('Webview received message:', message.command, message);
                    
                    switch (message.command) {
                        case 'authStatus':
                            console.log('Updating auth status - authenticated:', message.isAuthenticated, 'user:', message.user?.first_name);
                            updateAuthStatus(message.isAuthenticated, message.user);
                            break;
                        case 'reload':
                            window.location.reload();
                            break;
                    }
                });

                function updateAuthStatus(isAuthenticated, user) {
                    console.log('updateAuthStatus called - authenticated:', isAuthenticated, 'user:', user?.first_name);
                    
                    const unauthenticatedView = document.getElementById('unauthenticated-view');
                    const authenticatedView = document.getElementById('authenticated-view');
                    const welcomeMessage = document.getElementById('welcome-message');
                    
                    console.log('DOM elements found:', { 
                        unauthenticatedView: !!unauthenticatedView, 
                        authenticatedView: !!authenticatedView, 
                        welcomeMessage: !!welcomeMessage 
                    });
                    
                    if (isAuthenticated && user) {
                        console.log('User authenticated - showing welcome message');
                        unauthenticatedView.style.display = 'none';
                        authenticatedView.style.display = 'block';
                        if (welcomeMessage) {
                            welcomeMessage.textContent = \`Welcome, \${user.first_name}!\`;
                            console.log('Welcome message updated to:', welcomeMessage.textContent);
                        }
                    } else {
                        console.log('User not authenticated - showing signup');
                        unauthenticatedView.style.display = 'block';
                        authenticatedView.style.display = 'none';
                    }
                }

                // Handle signup button click
                document.getElementById('signupBtn').addEventListener('click', () => {
                    vscode.postMessage({ command: 'googleSignup' });
                });

                // DEV MODE: Add keyboard shortcut for quick reload
                document.addEventListener('keydown', (e) => {
                    if (e.ctrlKey && e.shiftKey && e.key === 'R') {
                        console.log('🔄 Dev reload triggered');
                        vscode.postMessage({ command: 'devReload' });
                    }
                });

                // Request initial auth status
                vscode.postMessage({ command: 'getAuthStatus' });
            </script>
        </body>
        </html>`;
    }
}

function getNonce() {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < 32; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}